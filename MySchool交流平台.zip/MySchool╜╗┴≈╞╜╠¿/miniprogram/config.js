

// 云开发环境ID
const CLOUNDID = 'cloud1-9g0tmo1k96e34884'
// 消息刷新时间，单位：毫秒
// 默认10秒刷新一次，即10000毫秒
// 根据实际需要进行调节
const FLASHTIME = 10000000

module.exports = {
    CLOUNDID,
    FLASHTIME
}